const express = require("express");
const studentsRouter = express.Router();
const PORT =6089;


const Student = require("../model/students");

studentsRouter.post("/add", async (req, res) => {
  let student_to_save = new Student({
    studentName: req.body.studentName,
    internshipStatus: req.body.internshipStatus,
    outstandingSubjects: req.body.outstandingSubjects,
  });

  try {
    let newStudent = await student_to_save.save();
    res.status(201).json(newStudent);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

studentsRouter.get("/view", async (req, res) => {
  try {
    const foundStudents = await Student.find();
    res.json(foundStudents);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

studentsRouter.get("/view/:id", async (req, res) => {
  try {
    const foundStudent = await Student.findById(req.params.id);
    res.json(foundStudent);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

studentsRouter.put("/update/:id", async (req, res) => {
  let studentID = req.params.id;

  await Student.findByIdAndUpdate(
    studentID,
    {
      studentName: req.body.studentName,
      internshipStatus: req.body.internshipStatus,
      outstandingSubjects: req.body.outstandingSubjects,
    },
    {
      new: true,
    }
  );
});

studentsRouter.delete("/delete/:id", async (req, res) => {
  let studentID = req.params.id;

  await Student.findByIdAndDelete(studentID);
});

module.exports = studentsRouter;

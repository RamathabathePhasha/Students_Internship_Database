//Import the modules
const express =require("express");
const mongoose =require("mongoose");
const studentsRouter=require("./routes");

//enviroment variables
require("dotenv").config();

//Connect to mongoDB
const DB_URL =process.env.DB_URL ||  "mongodb://localhost:27017/students"

//Error handling for mongoDB connection
try {
  mongoose.connect(DB_URL);
} catch (error) {
  console.log(error);
}

//Create express app
const app= express();

//Middleware for JSON 
app.use(express.json());

//Routes
app.use("/students",studentsRouter);

//Start the server
const PORT = process.env.PORT || 6088;
const HOST = process.env.HOST || '127.0.0.1:27017' 
app.listen(PORT,HOST,() =>{
 console.log(`Server is running on http://${HOST}:${PORT}`);
});

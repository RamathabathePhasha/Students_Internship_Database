const mongoose =require("mongoose");
const { type } = require("os");

const modelName ="students";

const studentSchema =new mongoose.Schema({
  studentName:{
    type: String,
    required:true,
  },
  internshipStatus:{
    type: String,
    required:true,
    enum:["placed","unplaced","unknown"],
  },
  outStandingSubjects:{
    type: Number,
    required:true,
    default:0,
  },
});

module.exports =mongoose.model(modelName,studentSchema);
const express = require("express");
const studentsRouter = express.Router();
const PORT =6089;


const Student = require("../model/students");

studentsRouter.post("/add", async (req, res) => {
  let student_to_save = new Student({
    studentName: req.body.studentName,
    internshipStatus: req.body.internshipStatus,
    outstandingSubjects: req.body.outstandingSubjects,
  });

  try {
    let newStudent = await student_to_save.save();
    res.status(201).json(newStudent);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

studentsRouter.get("/view", async (req, res) => {
  try {
    const foundStudents = await Student.find();
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

studentsRouter.get("/view/:id", async (req, res) => {
  try {
    const foundStudent = await Student.findById(req.params.id);
    if (foundStudent) {
      res.json(foundStudent);
    } else{
      res.status(404).json({message:"The student is not found"});
    }
   
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

studentsRouter.put("/update/:id", async (req, res) => {
  let studentID = req.params.id;

  await Student.findByIdAndUpdate(
    studentID,
    {
      studentName: req.body.studentName,
      internshipStatus: req.body.internshipStatus,
      outstandingSubjects: req.body.outstandingSubjects,
    },
    {
      new: true,
    }
  );
});

studentsRouter.delete("/delete/:id", async (req, res) => {
  let studentID = req.params.id;
try{
 const deletedStudent = await Student.findByIdAndDelete(studentID);

if (deletedStudent) {
  res.json({message:"Student deleted"})
} else{
res.status(404).json({message:"Student not found"});
}
}catch (error) {
  res.status(500).json({ message: error.message });
}
});

module.exports = studentsRouter;

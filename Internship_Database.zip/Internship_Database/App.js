const express =require("express");
const mongoose =require("mongoose");
const studentsRouter=require("./routes");


require("dotenv").config();


const DB_URL =process.env.DB_URL ||  "mongodb://localhost:27017/students"


try {
  mongoose.connect(DB_URL);
} catch (error) {
  console.log(error);
}


const app= express();


app.use(express.json());


app.use("/students",studentsRouter);


const PORT = process.env.PORT || 6088;
const HOST = process.env.HOST || '127.0.0.1:27017' 
app.listen(PORT,HOST,() =>{
 console.log(`Server is running on http://${HOST}:${PORT}`);
});
